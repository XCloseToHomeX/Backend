package com.upc.travellerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravellerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
