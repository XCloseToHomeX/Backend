package com.upc.travellerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravellerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravellerserviceApplication.class, args);
	}

}
